package commands;
import mainPackage.*;
import java.lang.reflect.Member;
import java.util.*;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.*;
import javax.security.auth.login.LoginException;

import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.requests.GatewayIntent;
import org.jetbrains.annotations.NotNull;
import net.dv8tion.jda.api.entities.channel.unions.MessageChannelUnion;
import net.dv8tion.jda.api.interactions.components.text.TextInput;

public class BotCommands extends ListenerAdapter {

    Map<String, Inventory> globalInventory = new HashMap<>();
    Random rand = new Random();

    @Override
    public void onMessageReceived(MessageReceivedEvent event) 
    {
        /*
         * Necessary fields to make code easier later on!
         */
        MessageChannelUnion channel = event.getChannel();
        String message = event.getMessage().toString();
        User currentUser = event.getAuthor();
        String ah = currentUser.getAsMention();

        /*
         * Catch if the sender is a bot!
         */
        if(event.getAuthor().isBot()) {
            return;
        }

        /*
         * Check for new user!
         */
        if(!globalInventory.containsKey(ah)) {
            Inventory userInv = new Inventory(ah);
            globalInventory.put(ah, userInv);
            channel.sendMessage("Welcome to the lake " + ah + "!").queue();
            return;
        }

        /*
         * Inventory command!
         */
        if(message.contains("/inventory")){
            channel.sendMessage(globalInventory.get(ah).getRods()).queue();
            channel.sendMessage(globalInventory.get(ah).getFish()).queue();
            channel.sendMessage(globalInventory.get(ah).getBaits()).queue();
        }     
        
        /*
         * Fish command!
         */
        if(message.contains("/fish")){
            channel.sendMessage("Which rod would you like to use?").queue();
            channel.sendMessage(globalInventory.get(ah).getRods()).queue();
        }
    }

}
