package mainPackage;
import java.util.*;

public class Inventory
{
    String owner;
    ArrayList<String> rods = new ArrayList<>();
    ArrayList<String> baits = new ArrayList<>();
    ArrayList<Fish> fish = new ArrayList<>();
    private int CarpCoins;

    public Inventory(String owner)
    {
        this.owner = owner;
        rods.add("Guppy Getter");
        baits.add("Worm");
        Fish fish = new Fish("Nemo", "Goldfish", 1);
        this.fish.add(fish);
        CarpCoins = 10;
    }

    public void addRod(String rod)
    {
        rods.add(rod);
    }

    public void addFish(Fish fish)
    {
        this.fish.add(fish);
    }

    public void addBait(String bait)
    {
        baits.add(bait);
    }

    public void addCoins(int add)
    {
        CarpCoins += add;
    }
    public String getRods()
    {
        return "Rods:\n" + rods.toString();
    }

    public String getBaits()
    {
        return "Baits:\n" + baits.toString();
    }

    public String getFish()
    {
        String returnString = owner + "'s Fish:\n";
        for(int i = 0; i < fish.size(); i++) {
            returnString += fish.get(i).getSize() + " inch " + fish.get(i).getType() + "\n";
        }
        return returnString;
    }

    public int getCoins()
    {
        return CarpCoins;
    }
}