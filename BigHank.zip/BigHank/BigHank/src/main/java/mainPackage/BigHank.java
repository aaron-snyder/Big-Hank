package mainPackage;
import commands.*;

import java.lang.reflect.Member;
import java.util.*;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.*;
import javax.security.auth.login.LoginException;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.requests.GatewayIntent;
import org.jetbrains.annotations.NotNull;
import net.dv8tion.jda.api.entities.channel.unions.MessageChannelUnion;

public class BigHank extends ListenerAdapter {
    

    public static void main(String[] args) throws LoginException
    {
        JDABuilder bot = JDABuilder.createDefault("OTYxODQ5MzMyMzM0NzQzNTUy.G3gPqz.OGEohUwe1PQN0-v44XYRtHswhji5BY_RTXs7b4");
        bot.setActivity(Activity.playing("bantz-big-bass-fishing"));
        bot.addEventListeners(new BotCommands());
        
        bot.enableIntents(GatewayIntent.GUILD_MEMBERS);
        bot.enableIntents(GatewayIntent.MESSAGE_CONTENT);
        bot.build();
    }
    
    
// Below code contains methods necessary for fishing process!
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    public static String determineType(String rod)
    {
        ArrayList<String> catchableFish = new ArrayList<>();
        switch(rod){
            case "Tuna Tamer":
                catchableFish.add("Tuna");
            case "Salmon Slapper":
                catchableFish.add("Salmon");
                catchableFish.add("Halibut");
            case "Catfish Clobberer":
                catchableFish.add("Rainbow Trout");
                catchableFish.add("Largemouth Bass");
                catchableFish.add("Catfish");
            case "Trout Tickler":
                catchableFish.add("Trout");
                catchableFish.add("Smallmouth Bass");
            case "Guppy Getter":
                catchableFish.add("Goldfish");
                catchableFish.add("Guppy");
                catchableFish.add("Pufferfish");
                break;     
            default:
                return null;       
        }
        Random r = new Random();
        String returnType = catchableFish.get(r.nextInt(0, catchableFish.size()));
        return returnType;
    }

    public static int determineSize(String type)
    {
        int returnInt = 0;
        return returnInt;
    }

    public static void store(String user){

    }
}
